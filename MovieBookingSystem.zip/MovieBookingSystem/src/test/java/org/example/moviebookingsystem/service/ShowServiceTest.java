package org.example.moviebookingsystem.service;

import org.example.moviebookingsystem.dto.BulkBookingRequest;
import org.example.moviebookingsystem.dto.BookingResponse;
import org.example.moviebookingsystem.exception.SeatUnavailableException;
import org.example.moviebookingsystem.model.Booking;
import org.example.moviebookingsystem.model.Seat;
import org.example.moviebookingsystem.model.Show;
import org.example.moviebookingsystem.repository.DummyDataStore;
import org.example.moviebookingsystem.repository.ShowRepository;
import org.example.moviebookingsystem.util.BookingStatus;
import org.example.moviebookingsystem.util.SeatStatus;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ShowServiceTest {

    private static final Integer SHOW_ID = 100;
    private static final Integer SEAT_NO = 1;
    private static final Integer SEAT_NO_2 = 2;

    @Autowired
    private ShowService showService;

    @Autowired
    private ShowRepository showRepository;

    private List<Seat> originalSeats;

    @BeforeEach
    void resetDummyState() {
        Show show = showRepository.findById(SHOW_ID);

        originalSeats = show.getSeats();

        Optional<Seat> maybeSeat = show.getSeats().stream()
                .filter(s -> s.getSeatNo().equals(SEAT_NO))
                .findFirst();
        assertTrue(maybeSeat.isPresent());
        maybeSeat.get().setSeatStatus(SeatStatus.AVAILABLE);

        Optional<Seat> maybeSeat2 = show.getSeats().stream()
                .filter(s -> s.getSeatNo().equals(SEAT_NO_2))
                .findFirst();
        assertTrue(maybeSeat2.isPresent());
        maybeSeat2.get().setSeatStatus(SeatStatus.AVAILABLE);

        DummyDataStore.BOOKINGS.removeIf(b -> b.getShowId().equals(SHOW_ID)
                && b.getSeatNos() != null
                && (b.getSeatNos().contains(SEAT_NO) || b.getSeatNos().contains(SEAT_NO_2)));
    }

    @AfterEach
    void restoreDummyState() {
        Show show = showRepository.findById(SHOW_ID);
        show.setSeats(originalSeats);

        DummyDataStore.BOOKINGS.removeIf(b -> b.getShowId().equals(SHOW_ID)
                && b.getSeatNos() != null
                && (b.getSeatNos().contains(SEAT_NO) || b.getSeatNos().contains(SEAT_NO_2)));

        Show restored = showRepository.findById(SHOW_ID);
        restored.getSeats().forEach(s -> {
            if (s.getSeatNo().equals(SEAT_NO) || s.getSeatNo().equals(SEAT_NO_2)) {
                s.setSeatStatus(SeatStatus.AVAILABLE);
            }
        });
    }

    @Test
    void bookShow_successfulBooking() {
        BookingResponse response = showService.bookShow(SHOW_ID, List.of(SEAT_NO));

        assertNotNull(response);
        assertNotNull(response.bookingId());
        assertEquals(BookingStatus.CONFIRMED, response.bookingStatus());

        Show show = showRepository.findById(SHOW_ID);
        Seat seat = show.getSeats().stream().filter(s -> s.getSeatNo().equals(SEAT_NO)).findFirst().orElseThrow();
        assertEquals(SeatStatus.BOOKED, seat.getSeatStatus());

        boolean bookingExists = DummyDataStore.BOOKINGS.stream()
                .map(Booking::getBookingId)
                .anyMatch(id -> id.equals(response.bookingId()));
        assertTrue(bookingExists);
    }

    @Test
    @Timeout(15)
    void bookShow_twoUsersSameSeatAtSameTime_onlyOneSucceeds() throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(2);
        CountDownLatch ready = new CountDownLatch(2);
        CountDownLatch start = new CountDownLatch(1);

        Callable<BookingResponse> task = () -> {
            ready.countDown();
            start.await();
            return showService.bookShow(SHOW_ID, List.of(SEAT_NO));
        };

        Future<BookingResponse> f1 = executor.submit(task);
        Future<BookingResponse> f2 = executor.submit(task);

        ready.await();
        start.countDown();

        BookingResponse r1 = null;
        BookingResponse r2 = null;
        Throwable e1 = null;
        Throwable e2 = null;

        try {
            try {
                r1 = f1.get();
            } catch (ExecutionException ex) {
                e1 = ex.getCause();
            }

            try {
                r2 = f2.get();
            } catch (ExecutionException ex) {
                e2 = ex.getCause();
            }
        } finally {
            executor.shutdownNow();
        }

        int successCount = (r1 != null ? 1 : 0) + (r2 != null ? 1 : 0);
        assertEquals(1, successCount);

        Throwable failure = e1 != null ? e1 : e2;
        assertNotNull(failure);
        assertTrue(failure instanceof SeatUnavailableException);

        BookingResponse success = r1 != null ? r1 : r2;
        assertEquals(BookingStatus.CONFIRMED, success.bookingStatus());

        Show show = showRepository.findById(SHOW_ID);
        Seat seat = show.getSeats().stream().filter(s -> s.getSeatNo().equals(SEAT_NO)).findFirst().orElseThrow();
        assertEquals(SeatStatus.BOOKED, seat.getSeatStatus());
    }

    @Test
    void bulkBookShows_successfulBookings() {
        List<BulkBookingRequest> requests = List.of(
                new BulkBookingRequest(SHOW_ID, List.of(SEAT_NO)),
                new BulkBookingRequest(SHOW_ID, List.of(SEAT_NO_2))
        );

        List<BookingResponse> responses = showService.bulkBookShows(requests);

        assertNotNull(responses);
        assertEquals(2, responses.size());
        assertTrue(responses.stream().allMatch(r -> r != null && r.bookingStatus() == BookingStatus.CONFIRMED));

        Show show = showRepository.findById(SHOW_ID);
        Seat seat1 = show.getSeats().stream().filter(s -> s.getSeatNo().equals(SEAT_NO)).findFirst().orElseThrow();
        Seat seat2 = show.getSeats().stream().filter(s -> s.getSeatNo().equals(SEAT_NO_2)).findFirst().orElseThrow();
        assertEquals(SeatStatus.BOOKED, seat1.getSeatStatus());
        assertEquals(SeatStatus.BOOKED, seat2.getSeatStatus());
    }

    @Test
    void cancelBooking_setsBookingCancelledAndReleasesSeats() {
        BookingResponse booked = showService.bookShow(SHOW_ID, List.of(SEAT_NO));
        assertNotNull(booked.bookingId());

        BookingResponse cancelled = showService.cancelBooking(booked.bookingId());

        assertEquals(BookingStatus.CANCELLED, cancelled.bookingStatus());
        Show show = showRepository.findById(SHOW_ID);
        Seat seat = show.getSeats().stream().filter(s -> s.getSeatNo().equals(SEAT_NO)).findFirst().orElseThrow();
        assertEquals(SeatStatus.AVAILABLE, seat.getSeatStatus());
    }

    @Test
    void updateSeatInventory_overwritesSeatList() {
        String msg = showService.updateSeatInventory(SHOW_ID, 3);
        assertEquals("Updated seat inventory successfully", msg);

        Show show = showRepository.findById(SHOW_ID);
        assertNotNull(show.getSeats());
        assertEquals(3, show.getSeats().size());
        assertTrue(show.getSeats().stream().allMatch(s -> s.getSeatStatus() == SeatStatus.AVAILABLE));
    }
}

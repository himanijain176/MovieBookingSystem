package org.example.moviebookingsystem.controller;

import org.example.moviebookingsystem.dto.BookingResponse;
import org.example.moviebookingsystem.exception.GlobalExceptionHandler;
import org.example.moviebookingsystem.exception.SeatUnavailableException;
import org.example.moviebookingsystem.service.ShowService;
import org.example.moviebookingsystem.util.BookingStatus;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class ShowControllerIntegrationTest {

    @Test
    void bookShow_success_returnsCreatedAndBookingResponse() throws Exception {
        ShowService showService = mock(ShowService.class);
        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(new ShowController(showService))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();

        when(showService.bookShow(anyInt(), any())).thenReturn(
                new BookingResponse(1, BookingStatus.CONFIRMED, null, null, null, java.util.List.of())
        );

        mockMvc.perform(post("/api/v1/shows/{showId}/bookings", 100)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("[1]"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.bookingId").exists())
                .andExpect(jsonPath("$.bookingStatus").value("CONFIRMED"));
    }

    @Test
    void bookShow_whenSeatAlreadyBooked_returnsConflict() throws Exception {
        ShowService showService = mock(ShowService.class);
        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(new ShowController(showService))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();

        when(showService.bookShow(anyInt(), any())).thenThrow(new SeatUnavailableException("Seat not available"));

        mockMvc.perform(post("/api/v1/shows/{showId}/bookings", 100)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("[1]"))
                .andExpect(status().isConflict());
    }
}

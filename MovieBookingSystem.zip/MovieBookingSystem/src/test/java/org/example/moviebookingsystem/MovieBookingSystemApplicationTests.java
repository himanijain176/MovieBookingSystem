package org.example.moviebookingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieBookingSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}

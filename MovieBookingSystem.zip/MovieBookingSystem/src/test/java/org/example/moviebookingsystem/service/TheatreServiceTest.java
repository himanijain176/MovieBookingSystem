package org.example.moviebookingsystem.service;

import org.example.moviebookingsystem.model.Show;
import org.example.moviebookingsystem.model.Theatre;
import org.example.moviebookingsystem.repository.DummyDataStore;
import org.example.moviebookingsystem.repository.ShowRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class TheatreServiceTest {

    @Autowired
    private TheatreService theatreService;

    @Autowired
    private ShowRepository showRepository;

    private Show originalShow;

    @BeforeEach
    void snapshotShow() {
        Show show = showRepository.findById(100);
        originalShow = new Show(
                show.getShowId(),
                show.getScreenId(),
                show.getMovieName(),
                show.getShowDate(),
                show.getStartTime(),
                show.getEndTime(),
                show.getSeats()
        );
    }

    @AfterEach
    void restoreShow() {
        Show show = showRepository.findById(100);
        show.setMovieName(originalShow.getMovieName());
        show.setShowDate(originalShow.getShowDate());
        show.setStartTime(originalShow.getStartTime());
        show.setEndTime(originalShow.getEndTime());
        show.setSeats(originalShow.getSeats());

        DummyDataStore.THEATRES.removeIf(t -> t.getTheatreId() != null && t.getTheatreId().equals(999));
    }

    @Test
    void addTheatre_addsToDummyStore() {
        int before = DummyDataStore.THEATRES.size();
        Theatre theatre = new Theatre(999, "Test Theatre", "Test City", new ArrayList<>());

        String msg = theatreService.addTheatre(theatre);

        assertEquals("Created New Theatre Successfully", msg);
        assertEquals(before + 1, DummyDataStore.THEATRES.size());
        assertTrue(DummyDataStore.THEATRES.stream().anyMatch(t -> t.getTheatreId().equals(999)));
    }

    @Test
    void updateShow_updatesExistingShow() {
        Show update = new Show(
                100,
                10,
                "Updated Movie",
                LocalDate.now().plusDays(2),
                LocalTime.of(9, 0),
                LocalTime.of(11, 0),
                originalShow.getSeats()
        );

        String msg = theatreService.updateShow(100, update);

        assertEquals("Updated show Successfully", msg);
        Show show = showRepository.findById(100);
        assertEquals("Updated Movie", show.getMovieName());
        assertEquals(update.getShowDate(), show.getShowDate());
        assertEquals(update.getStartTime(), show.getStartTime());
        assertEquals(update.getEndTime(), show.getEndTime());
    }

    @Test
    void deleteShow_removesShow() {
        Show temp = new Show(9999, 10, "Temp", LocalDate.now(), LocalTime.of(8, 0), LocalTime.of(9, 0), List.of());
        DummyDataStore.SHOWS.add(temp);

        String msg = theatreService.deleteShow(9999);

        assertEquals("Delete show Successfully", msg);
        assertTrue(DummyDataStore.SHOWS.stream().noneMatch(s -> s.getShowId().equals(9999)));
    }
}

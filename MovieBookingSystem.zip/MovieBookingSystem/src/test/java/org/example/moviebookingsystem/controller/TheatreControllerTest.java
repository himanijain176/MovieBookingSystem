package org.example.moviebookingsystem.controller;

import org.example.moviebookingsystem.exception.GlobalExceptionHandler;
import org.example.moviebookingsystem.service.ShowService;
import org.example.moviebookingsystem.service.TheatreService;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class TheatreControllerTest {

    @Test
    void addTheatre_returnsCreated() throws Exception {
        TheatreService theatreService = mock(TheatreService.class);
        ShowService showService = mock(ShowService.class);
        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(new TheatreController(theatreService, showService))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();

        when(theatreService.addTheatre(any())).thenReturn("Created New Theatre Successfully");

        mockMvc.perform(post("/api/v1/theatres")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"theatreId\":1,\"theatreName\":\"X\",\"cityName\":\"Y\",\"screens\":[]}"))
                .andExpect(status().isCreated());
    }

    @Test
    void updateSeatInventory_returnsOk() throws Exception {
        TheatreService theatreService = mock(TheatreService.class);
        ShowService showService = mock(ShowService.class);
        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(new TheatreController(theatreService, showService))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();

        when(showService.updateSeatInventory(anyInt(), anyInt())).thenReturn("Updated seat inventory successfully");

        mockMvc.perform(put("/api/v1/shows/{showId}/seats", 100)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"seatCount\":5}"))
                .andExpect(status().isOk());
    }

    @Test
    void deleteShow_returnsOk() throws Exception {
        TheatreService theatreService = mock(TheatreService.class);
        ShowService showService = mock(ShowService.class);
        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(new TheatreController(theatreService, showService))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();

        when(theatreService.deleteShow(anyInt())).thenReturn("Delete show Successfully");

        mockMvc.perform(delete("/api/v1/shows/{showId}", 100))
                .andExpect(status().isOk());
    }

    @Test
    void updateShow_returnsOk() throws Exception {
        TheatreService theatreService = mock(TheatreService.class);
        ShowService showService = mock(ShowService.class);
        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(new TheatreController(theatreService, showService))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();

        when(theatreService.updateShow(anyInt(), any())).thenReturn("Updated show Successfully");

        mockMvc.perform(patch("/api/v1/shows/{showId}", 100)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"showId\":100,\"screenId\":10,\"movieName\":\"X\",\"showDate\":\"2026-02-01\",\"startTime\":\"10:00:00\",\"endTime\":\"12:00:00\",\"seats\":[]}"))
                .andExpect(status().isOk());
    }
}

package org.example.moviebookingsystem.controller;

import org.example.moviebookingsystem.dto.OfferResponse;
import org.example.moviebookingsystem.exception.GlobalExceptionHandler;
import org.example.moviebookingsystem.service.OfferService;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class OfferControllerTest {

    @Test
    void getOffers_returnsOk() throws Exception {
        OfferService offerService = mock(OfferService.class);
        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(new OfferController(offerService))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();

        when(offerService.getOffers(anyInt(), any(), any())).thenReturn(new OfferResponse(List.of()));

        mockMvc.perform(get("/api/v1/offers")
                        .queryParam("theatreId", "1")
                        .queryParam("cityName", "Bangalore")
                        .queryParam("date", "2026-02-01"))
                .andExpect(status().isOk());
    }
}

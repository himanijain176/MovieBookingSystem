package org.example.moviebookingsystem.repository;

import org.example.moviebookingsystem.model.Offer;

import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public class OfferRepository {

    public List<Offer> findValidOffers(Integer theatreId, String cityName, LocalDate date) {
        return DummyDataStore.OFFERS.stream()
                .filter(offers -> offers.getTheatreId().equals(theatreId))
                .filter(offerCity -> offerCity.getCityName().equalsIgnoreCase(cityName))
                .filter(offerDate -> !offerDate.getValidFrom().isAfter(date) && !offerDate.getValidTo().isBefore(date))
                .toList();
    }
}

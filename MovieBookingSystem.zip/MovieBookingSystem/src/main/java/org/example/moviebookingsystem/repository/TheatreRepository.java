package org.example.moviebookingsystem.repository;

import org.example.moviebookingsystem.exception.ResourceNotFoundException;
import org.example.moviebookingsystem.model.Screen;
import org.example.moviebookingsystem.model.Theatre;

import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TheatreRepository {

    public Theatre findById(Integer theatreId) {
        return DummyDataStore.THEATRES.stream()
                .filter(t -> t.getTheatreId().equals(theatreId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Theatre", theatreId));
    }

    public List<Theatre> findByCity(String city) {
        return DummyDataStore.THEATRES.stream()
                .filter(t -> t.getCityName().equalsIgnoreCase(city))
                .toList();
    }

    public Theatre findTheatreForScreen(Integer screenId) {
        return DummyDataStore.THEATRES.stream()
                .filter(t -> t.getScreens().stream().anyMatch(s -> s.getScreenId().equals(screenId)))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Theatre for screen", screenId));
    }

    public Screen findScreen(Theatre theatre, Integer screenId) {
        return theatre.getScreens().stream()
                .filter(s -> s.getScreenId().equals(screenId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Screen", screenId));
    }

    public void save(Theatre theatre) {
        DummyDataStore.THEATRES.add(theatre);
    }
}

package org.example.moviebookingsystem.controller;

import org.example.moviebookingsystem.dto.BulkBookingRequest;
import org.example.moviebookingsystem.dto.BookingResponse;
import org.example.moviebookingsystem.dto.ShowResponse;
import org.example.moviebookingsystem.service.ShowService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class ShowController {

    ShowService showService;

    public ShowController(ShowService showService){
        this.showService = showService;
    }

    @GetMapping("/shows")
    public ResponseEntity<List<ShowResponse>> getShows(
            @RequestParam String movieName,
            @RequestParam String city,
            @RequestParam LocalDate date
    ) {
        List<ShowResponse> showResponses = showService.getShows(movieName,city,date);
        return ResponseEntity.ok(showResponses);
    }

    @PostMapping("/shows/{showId}/bookings")
    public ResponseEntity<BookingResponse> bookShow(@PathVariable Integer showId,
                                                    @RequestBody List<Integer> seatNo){

        BookingResponse bookingResponse = showService.bookShow(showId,seatNo);
        return ResponseEntity.status(HttpStatus.CREATED).body(bookingResponse);
    }

    @PostMapping("/bookings/bulk")
    public ResponseEntity<List<BookingResponse>> bulkBookShows(@RequestBody List<BulkBookingRequest> requests) {
        List<BookingResponse> responses = showService.bulkBookShows(requests);
        return ResponseEntity.status(HttpStatus.CREATED).body(responses);
    }

    @DeleteMapping("/bookings")
    public ResponseEntity<BookingResponse> cancelBooking(@RequestBody Integer bookingId){

        BookingResponse bookingResponse = showService.cancelBooking(bookingId);
        return ResponseEntity.ok(bookingResponse);
    }

    @DeleteMapping("/bookings/bulk")
    public ResponseEntity<List<BookingResponse>> cancelBookings(@RequestBody List<Integer> bookingIds){
        List<BookingResponse> bookingResponses = showService.cancelBookings(bookingIds);
        return ResponseEntity.ok(bookingResponses);
    }
}

package org.example.moviebookingsystem.exception;

public record ApiErrorResponse(
        String message
) {
}

package org.example.moviebookingsystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.moviebookingsystem.util.SeatStatus;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Seat {

    private Integer seatNo;
    private SeatStatus seatStatus;

}

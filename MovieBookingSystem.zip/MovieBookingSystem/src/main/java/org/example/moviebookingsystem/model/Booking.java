package org.example.moviebookingsystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.moviebookingsystem.util.BookingStatus;

import java.util.List;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {


    private Integer bookingId;
    private Integer showId;
    private BookingStatus bookingStatus;
    private Instant bookingTime;
    private List<Integer> seatNos;


}

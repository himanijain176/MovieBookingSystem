package org.example.moviebookingsystem.util;

public enum SeatStatus {
    AVAILABLE,
    BLOCKED,
    RESERVED,
    BOOKED
}

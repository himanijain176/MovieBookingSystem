package org.example.moviebookingsystem.dto;

import org.example.moviebookingsystem.util.BookingStatus;

import java.util.List;

public record BookingResponse(

    Integer bookingId,
    BookingStatus bookingStatus,
    Integer totalAmount,
    Integer discountAmount,
    Integer finalAmount,
    List<String> appliedOffers
    ){}

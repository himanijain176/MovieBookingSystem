package org.example.moviebookingsystem.service;

import org.example.moviebookingsystem.dto.BookingResponse;
import org.example.moviebookingsystem.dto.BulkBookingRequest;
import org.example.moviebookingsystem.dto.ShowResponse;
import org.example.moviebookingsystem.exception.SeatUnavailableException;
import org.example.moviebookingsystem.model.*;
import org.example.moviebookingsystem.repository.BookingRepository;
import org.example.moviebookingsystem.repository.ShowRepository;
import org.example.moviebookingsystem.repository.TheatreRepository;
import org.example.moviebookingsystem.service.pricing.PricingService;
import org.example.moviebookingsystem.util.BookingStatus;
import org.example.moviebookingsystem.util.PaymentHelper;
import org.example.moviebookingsystem.util.PaymentStatus;
import org.example.moviebookingsystem.util.SeatStatus;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.random.RandomGenerator;

@Service
public class ShowService {

    private static final Map<String, ReentrantLock> SEAT_LOCKS = new ConcurrentHashMap<>();

    private static final Duration PAYMENT_HOLD_DURATION = Duration.ofMinutes(5);

    private static final ScheduledExecutorService HOLD_EXPIRY_SCHEDULER = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r);
        t.setDaemon(true);
        t.setName("seat-hold-expiry");
        return t;
    });

    private final ShowRepository showRepository;
    private final TheatreRepository theatreRepository;
    private final BookingRepository bookingRepository;
    private final PricingService pricingService;

    public ShowService(
            ShowRepository showRepository,
            TheatreRepository theatreRepository,
            BookingRepository bookingRepository,
            PricingService pricingService
    ) {
        this.showRepository = showRepository;
        this.theatreRepository = theatreRepository;
        this.bookingRepository = bookingRepository;
        this.pricingService = pricingService;
    }

    private static ReentrantLock lockForSeat(Integer showId, Integer seatNo) {
        String key = showId + ":" + seatNo;
        return SEAT_LOCKS.computeIfAbsent(key, ignored -> new ReentrantLock(true));
    }

    public List<ShowResponse> getShows(String movieName, String city, LocalDate date) {
           if (movieName == null || movieName.isBlank() || city == null || city.isBlank() || date == null) {
               throw new IllegalArgumentException("movieName, city and date are required");
           }
           List<Theatre> theatreList = theatreRepository.findByCity(city);
          List<ShowResponse> showResponses = new ArrayList<>();
           for(Theatre theartre:theatreList){
               List<Screen> screens = theartre.getScreens();
               List<Show> showResult = new ArrayList<>();
               for(Screen screen:screens){
                   List<Show> shows = screen.getShows();
                   for(Show show:shows){
                       if(show.getShowDate().isEqual(date) && show.getMovieName().equalsIgnoreCase(movieName)){
                           showResult.add(show);
                       }
                   }

               }

               if (!showResult.isEmpty()) {
                   ShowResponse showResponse = new ShowResponse(theartre.getTheatreName(), List.copyOf(showResult));
                   showResponses.add(showResponse);
               }
            }

          return showResponses;
    }

    public BookingResponse bookShow(Integer showId, List<Integer> seatNo)  {
        if (showId == null) {
            throw new IllegalArgumentException("showId is required");
        }
        if (seatNo == null || seatNo.isEmpty()) {
            throw new IllegalArgumentException("seatNo must not be empty");
        }

        List<Integer> requestedSeats = new ArrayList<>(seatNo);
        Collections.sort(requestedSeats);

        List<ReentrantLock> acquiredLocks = new ArrayList<>();
        for (Integer requestedSeatNo : requestedSeats) {
            ReentrantLock lock = lockForSeat(showId, requestedSeatNo);
            lock.lock();
            acquiredLocks.add(lock);
        }

        try {
            Show show = showRepository.findById(showId);

            List<Seat> seats = show.getSeats();
            List<Seat> bookingSeat = new ArrayList<>();

            for (Integer requestedSeatNo : requestedSeats) {
                Optional<Seat> maybeSeat = seats.stream()
                        .filter(seat -> seat.getSeatNo().equals(requestedSeatNo))
                        .findFirst();

                if (maybeSeat.isEmpty()) {
                    throw new SeatUnavailableException("Seat not found: " + requestedSeatNo);
                }
                if (!maybeSeat.get().getSeatStatus().equals(SeatStatus.AVAILABLE)) {
                    throw new SeatUnavailableException("Seat not available: " + requestedSeatNo);
                }
                bookingSeat.add(maybeSeat.get());
            }

            updateBookingStatus(bookingSeat,SeatStatus.BLOCKED);

            scheduleHoldExpiry(showId, requestedSeats);

            String paymentStatus = PaymentHelper.getPaymentStatus();
            if(paymentStatus.equalsIgnoreCase(PaymentStatus.SUCCESS.toString())){
                updateBookingStatus(bookingSeat,SeatStatus.BOOKED);
                Booking booking = new Booking(RandomGenerator.getDefault().nextInt(1,1000), showId, BookingStatus.CONFIRMED, Instant.now(),seatNo);
                bookingRepository.save(booking);

                PricingService.PricingResult pricingResult = pricingService.calculatePricing(show, seatNo);
                return new BookingResponse(
                        booking.getBookingId(),
                        booking.getBookingStatus(),
                        pricingResult.totalAmount(),
                        pricingResult.discountAmount(),
                        pricingResult.finalAmount(),
                        pricingResult.appliedOffers()
                );
            }

            updateBookingStatus(bookingSeat,SeatStatus.AVAILABLE);
            return new BookingResponse(null, BookingStatus.CANCELLED, null, null, null, List.of());
        } finally {
            for (int i = acquiredLocks.size() - 1; i >= 0; i--) {
                ReentrantLock lock = acquiredLocks.get(i);
                Integer seatNumber = requestedSeats.get(i);
                lock.unlock();
                if (!lock.isLocked() && !lock.hasQueuedThreads()) {
                    SEAT_LOCKS.remove(showId + ":" + seatNumber, lock);
                }
            }
        }
    }

    private void scheduleHoldExpiry(Integer showId, List<Integer> seatNos) {
        long delayMs = PAYMENT_HOLD_DURATION.toMillis();
        HOLD_EXPIRY_SCHEDULER.schedule(() -> releaseSeatsIfStillBlocked(showId, seatNos), delayMs, TimeUnit.MILLISECONDS);
    }

    private void releaseSeatsIfStillBlocked(Integer showId, List<Integer> seatNos) {
        if (showId == null || seatNos == null || seatNos.isEmpty()) {
            return;
        }

        List<Integer> sortedSeatNos = new ArrayList<>(seatNos);
        Collections.sort(sortedSeatNos);

        List<ReentrantLock> acquiredLocks = new ArrayList<>();
        for (Integer seatNo : sortedSeatNos) {
            ReentrantLock lock = lockForSeat(showId, seatNo);
            lock.lock();
            acquiredLocks.add(lock);
        }

        try {
            Show show = showRepository.findById(showId);
            for (Integer seatNo : sortedSeatNos) {
                for (Seat seat : show.getSeats()) {
                    if (seat.getSeatNo().equals(seatNo) && seat.getSeatStatus() == SeatStatus.BLOCKED) {
                        seat.setSeatStatus(SeatStatus.AVAILABLE);
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            for (int i = acquiredLocks.size() - 1; i >= 0; i--) {
                ReentrantLock lock = acquiredLocks.get(i);
                Integer seatNumber = sortedSeatNos.get(i);
                lock.unlock();
                if (!lock.isLocked() && !lock.hasQueuedThreads()) {
                    SEAT_LOCKS.remove(showId + ":" + seatNumber, lock);
                }
            }
        }
    }

    private void updateBookingStatus(List<Seat> bookingSeat,SeatStatus status) {
        for(Seat seat:bookingSeat){
             seat.setSeatStatus(status);
        }
    }

    public BookingResponse cancelBooking(Integer bookingId) {
        if (bookingId == null) {
            throw new IllegalArgumentException("bookingId is required");
        }

        Booking booking = bookingRepository.findById(bookingId);

        booking.setBookingStatus(BookingStatus.CANCELLED);
        Integer showId = booking.getShowId();
        List<Integer> seatNo = booking.getSeatNos();
        List<Seat> seatList = showRepository.findById(showId).getSeats();
        for(Seat seat:seatList){
            if(seatNo.contains(seat.getSeatNo())){
                seat.setSeatStatus(SeatStatus.AVAILABLE);
            }
        }
        return new BookingResponse(bookingId,BookingStatus.CANCELLED, null, null, null, List.of());

    }

    public List<BookingResponse> bulkBookShows(List<Integer> showIds, List<List<Integer>> seatNos) {
        if (showIds == null || seatNos == null || showIds.size() != seatNos.size()) {
            throw new IllegalArgumentException("showIds and seatNos are required and must have same length");
        }

        List<BookingResponse> responses = new ArrayList<>();
        for (int i = 0; i < showIds.size(); i++) {
            responses.add(bookShow(showIds.get(i), seatNos.get(i)));
        }
        return responses;
    }

    public List<BookingResponse> bulkBookShows(List<BulkBookingRequest> requests) {
        if (requests == null || requests.isEmpty()) {
            throw new IllegalArgumentException("requests must not be empty");
        }

        List<BookingResponse> responses = new ArrayList<>();
        for (BulkBookingRequest request : requests) {
            if (request == null) {
                throw new IllegalArgumentException("request must not be null");
            }
            responses.add(bookShow(request.showId(), request.seatNos()));
        }
        return responses;
    }

    public List<BookingResponse> cancelBookings(List<Integer> bookingIds) {
        if (bookingIds == null || bookingIds.isEmpty()) {
            throw new IllegalArgumentException("bookingIds must not be empty");
        }
        List<BookingResponse> responses = new ArrayList<>();
        for (Integer bookingId : bookingIds) {
            responses.add(cancelBooking(bookingId));
        }
        return responses;
    }

    public String updateSeatInventory(Integer showId, Integer seatCount) {
        if (showId == null || seatCount == null) {
            throw new IllegalArgumentException("showId and seatCount are required");
        }
        if (seatCount <= 0) {
            throw new IllegalArgumentException("seatCount must be > 0");
        }

        Show show = showRepository.findById(showId);

        List<Seat> seats = new ArrayList<>();
        for (int i = 1; i <= seatCount; i++) {
            seats.add(new Seat(i, SeatStatus.AVAILABLE));
        }
        show.setSeats(seats);
        return "Updated seat inventory successfully";
    }
}

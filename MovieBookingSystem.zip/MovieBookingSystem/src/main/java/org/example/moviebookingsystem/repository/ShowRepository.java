package org.example.moviebookingsystem.repository;

import org.example.moviebookingsystem.exception.ResourceNotFoundException;
import org.example.moviebookingsystem.model.Show;

import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public class ShowRepository {

    public Show findById(Integer showId) {
        return DummyDataStore.SHOWS.stream()
                .filter(s -> s.getShowId().equals(showId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Show", showId));
    }

    public List<Show> findByMovieAndDate(String movieName, LocalDate date) {
        return DummyDataStore.SHOWS.stream()
                .filter(s -> s.getShowDate().isEqual(date))
                .filter(s -> s.getMovieName().equalsIgnoreCase(movieName))
                .toList();
    }

    public void save(Show show) {
        DummyDataStore.SHOWS.add(show);
    }

    public void delete(Show show) {
        DummyDataStore.SHOWS.remove(show);
    }
}

package org.example.moviebookingsystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Theatre {
    
    private Integer theatreId;
    private String theatreName;
    private String cityName;
    private List<Screen> screens;
}

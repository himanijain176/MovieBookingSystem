package org.example.moviebookingsystem.service;

import org.example.moviebookingsystem.model.Screen;
import org.example.moviebookingsystem.model.Show;
import org.example.moviebookingsystem.model.Theatre;
import org.example.moviebookingsystem.repository.ShowRepository;
import org.example.moviebookingsystem.repository.TheatreRepository;
import org.springframework.stereotype.Service;

@Service
public class TheatreService {

    private final TheatreRepository theatreRepository;
    private final ShowRepository showRepository;

    public TheatreService(TheatreRepository theatreRepository, ShowRepository showRepository) {
        this.theatreRepository = theatreRepository;
        this.showRepository = showRepository;
    }

    public String addTheatre(Theatre theatre) {
        theatreRepository.save(theatre);
        return "Created New Theatre Successfully";
    }

    public String createShow(Integer theatreId, Integer screenId, Show show) {
        if (theatreId == null || screenId == null || show == null) {
            throw new IllegalArgumentException("theatreId, screenId and show are required");
        }

        Theatre theatre = theatreRepository.findById(theatreId);
        Screen screen = theatreRepository.findScreen(theatre, screenId);

        screen.getShows().add(show);
        showRepository.save(show);
        return "Created New show Successfully";
    }

    public String updateShow(Integer showId, Show show) {
        if (showId == null || show == null) {
            throw new IllegalArgumentException("showId and show are required");
        }

        Show currentShow = showRepository.findById(showId);
        currentShow.setShowDate(show.getShowDate());
        currentShow.setSeats(show.getSeats());
        currentShow.setMovieName(show.getMovieName());
        currentShow.setStartTime(show.getStartTime());
        currentShow.setEndTime(show.getEndTime());
        return "Updated show Successfully";
    }


    public String deleteShow(Integer showId) {
        if (showId == null) {
            throw new IllegalArgumentException("showId is required");
        }

        Show deleteShow = showRepository.findById(showId);
        showRepository.delete(deleteShow);
        return "Delete show Successfully";
    }
}

package org.example.moviebookingsystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Offer {
    
    private Integer offerId;
    private Integer theatreId;
    private String cityName;
    private String offerDescription;
    private LocalDate validFrom;
    private LocalDate validTo;
}

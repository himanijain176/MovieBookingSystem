package org.example.moviebookingsystem.dto;

import java.util.List;

public record BulkBookingRequest(
        Integer showId,
        List<Integer> seatNos
) {
}

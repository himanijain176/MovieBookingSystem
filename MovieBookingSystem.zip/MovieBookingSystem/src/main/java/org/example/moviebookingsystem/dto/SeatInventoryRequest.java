package org.example.moviebookingsystem.dto;

public record SeatInventoryRequest(
        Integer seatCount
) {
}

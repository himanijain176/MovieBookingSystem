package org.example.moviebookingsystem.util;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}

package org.example.moviebookingsystem.repository;

import org.example.moviebookingsystem.exception.ResourceNotFoundException;
import org.example.moviebookingsystem.model.Booking;

import org.springframework.stereotype.Repository;

@Repository
public class BookingRepository {

    public Booking findById(Integer bookingId) {
        return DummyDataStore.BOOKINGS.stream()
                .filter(b -> b.getBookingId().equals(bookingId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Booking", bookingId));
    }

    public void save(Booking booking) {
        DummyDataStore.BOOKINGS.add(booking);
    }
}

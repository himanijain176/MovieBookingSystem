package org.example.moviebookingsystem.controller;

import org.example.moviebookingsystem.model.Show;
import org.example.moviebookingsystem.model.Theatre;
import org.example.moviebookingsystem.dto.SeatInventoryRequest;
import org.example.moviebookingsystem.service.ShowService;
import org.example.moviebookingsystem.service.TheatreService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class TheatreController {

    TheatreService theatreService;
    ShowService showService;

    public TheatreController(TheatreService theatreService, ShowService showService){
        this.theatreService = theatreService;
        this.showService = showService;
    }

    @PostMapping("/theatres")
    public ResponseEntity<String> addTheatre(@RequestBody Theatre theatre) {
        String theatreResponse = theatreService.addTheatre(theatre);
        return ResponseEntity.status(HttpStatus.CREATED).body(theatreResponse);
    }

    @PostMapping("/theatres/{theatreId}/screen/{screenId}")
    public ResponseEntity<String> createShow(
            @PathVariable Integer theatreId,
            @PathVariable Integer screenId,
            @RequestBody Show show
    ){
        String showResponse = theatreService.createShow(theatreId,screenId,show);
        return ResponseEntity.ok(showResponse);
    }

    @PatchMapping("/shows/{showId}")
    public ResponseEntity<String> updateShow(
            @PathVariable Integer showId,
            @RequestBody Show show
    ){
        String showResponse = theatreService.updateShow(showId,show);
        return ResponseEntity.ok(showResponse);
    }

    @DeleteMapping("/shows/{showId}")
    public ResponseEntity<String> deleteShow(
            @PathVariable Integer showId
    ){
        String showResponse = theatreService.deleteShow(showId);
        return ResponseEntity.ok(showResponse);
    }

    @PutMapping("/shows/{showId}/seats")
    public ResponseEntity<String> updateSeatInventory(
            @PathVariable Integer showId,
            @RequestBody SeatInventoryRequest request
    ) {
        String response = showService.updateSeatInventory(showId, request.seatCount());
        return ResponseEntity.ok(response);
    }
}

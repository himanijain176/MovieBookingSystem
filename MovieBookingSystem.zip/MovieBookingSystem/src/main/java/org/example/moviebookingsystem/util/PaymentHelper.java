package org.example.moviebookingsystem.util;

public class PaymentHelper {

    public static String getPaymentStatus(){
        return String.valueOf(PaymentStatus.SUCCESS);
    }
}

package org.example.moviebookingsystem.service;

import org.example.moviebookingsystem.dto.OfferResponse;
import org.example.moviebookingsystem.model.Offer;
import org.example.moviebookingsystem.repository.OfferRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class OfferService {

    private final OfferRepository offerRepository;

    public OfferService(OfferRepository offerRepository) {
        this.offerRepository = offerRepository;
    }


    public OfferResponse getOffers(Integer theatreId, String cityName, LocalDate date) {
        List<Offer> offerList = offerRepository.findValidOffers(theatreId, cityName, date);
        return new OfferResponse(offerList);
    }
}

package org.example.moviebookingsystem.dto;

import org.example.moviebookingsystem.model.Offer;

import java.util.List;

public record OfferResponse(
        List<Offer> offers
) {
}

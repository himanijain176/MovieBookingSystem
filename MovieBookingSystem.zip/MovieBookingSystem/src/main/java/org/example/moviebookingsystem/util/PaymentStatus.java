package org.example.moviebookingsystem.util;

public enum PaymentStatus {

    CANCELLED,
    SUCCESS,
    FAILURE
}

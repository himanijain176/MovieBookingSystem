package org.example.moviebookingsystem.service.pricing;

import org.example.moviebookingsystem.model.Show;
import org.example.moviebookingsystem.model.Theatre;
import org.example.moviebookingsystem.repository.OfferRepository;
import org.example.moviebookingsystem.repository.TheatreRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class DefaultPricingService implements PricingService {

    private static final int TICKET_PRICE = 100;

    private final TheatreRepository theatreRepository;
    private final OfferRepository offerRepository;

    public DefaultPricingService(TheatreRepository theatreRepository, OfferRepository offerRepository) {
        this.theatreRepository = theatreRepository;
        this.offerRepository = offerRepository;
    }

    @Override
    public PricingResult calculatePricing(Show show, List<Integer> seatNos) {
        int tickets = seatNos.size();
        int totalAmount = tickets * TICKET_PRICE;

        List<String> appliedOffers = new ArrayList<>();

        int discountThirdTicket = 0;
        boolean thirdTicketOfferApplicable = hasOffer(show, "50%", "third");
        if (thirdTicketOfferApplicable) {
            discountThirdTicket = (tickets / 3) * (TICKET_PRICE / 2);
            if (discountThirdTicket > 0) {
                appliedOffers.add("50% discount on the third ticket");
            }
        }

        int runningAmount = totalAmount - discountThirdTicket;

        int discountAfternoon = 0;
        boolean afternoonOfferApplicable = hasOffer(show, "20%", "afternoon") && isAfternoonShow(show);
        if (afternoonOfferApplicable) {
            discountAfternoon = (int) Math.round(runningAmount * 0.20d);
            if (discountAfternoon > 0) {
                appliedOffers.add("20% discount on afternoon shows");
            }
        }

        int discountAmount = discountThirdTicket + discountAfternoon;
        int finalAmount = Math.max(0, totalAmount - discountAmount);
        return new PricingResult(totalAmount, discountAmount, finalAmount, List.copyOf(appliedOffers));
    }

    private boolean hasOffer(Show show, String... containsAllTokens) {
        Theatre theatre = theatreForShow(show);
        LocalDate showDate = show.getShowDate();

        return offerRepository.findValidOffers(theatre.getTheatreId(), theatre.getCityName(), showDate).stream()
                .anyMatch(o -> {
                    String desc = o.getOfferDescription() == null ? "" : o.getOfferDescription().toLowerCase();
                    for (String token : containsAllTokens) {
                        if (!desc.contains(token.toLowerCase())) {
                            return false;
                        }
                    }
                    return true;
                });
    }

    private Theatre theatreForShow(Show show) {
        Integer screenId = show.getScreenId();
        return theatreRepository.findTheatreForScreen(screenId);
    }

    private boolean isAfternoonShow(Show show) {
        if (show.getStartTime() == null) {
            return false;
        }
        int hour = show.getStartTime().getHour();
        return hour >= 12 && hour < 17;
    }
}

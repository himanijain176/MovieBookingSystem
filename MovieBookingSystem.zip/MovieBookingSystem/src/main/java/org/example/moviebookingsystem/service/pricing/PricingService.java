package org.example.moviebookingsystem.service.pricing;

import org.example.moviebookingsystem.model.Show;

import java.util.List;

public interface PricingService {

    PricingResult calculatePricing(Show show, List<Integer> seatNos);

    record PricingResult(int totalAmount, int discountAmount, int finalAmount, List<String> appliedOffers) {
    }
}

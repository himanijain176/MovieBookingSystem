package org.example.moviebookingsystem.repository;

import org.example.moviebookingsystem.model.*;
import org.example.moviebookingsystem.util.BookingStatus;
import org.example.moviebookingsystem.util.SeatStatus;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public final class DummyDataStore {

    public static final List<Movie> MOVIES;
    public static final List<Offer> OFFERS;
    public static final List<Theatre> THEATRES;
    public static final List<Screen> SCREENS;
    public static final List<Show> SHOWS;
    public static final List<Booking> BOOKINGS;

    static {
        Movie movie1 = new Movie(1, "Inception", LocalDate.of(2010, 7, 16), "Sci-Fi", "English");
        Movie movie2 = new Movie(2, "3 Idiots", LocalDate.of(2009, 12, 25), "Comedy/Drama", "Hindi");
        Movie movie3 = new Movie(3, "Interstellar", LocalDate.of(2014, 11, 7), "Sci-Fi", "English");
        Movie movie4 = new Movie(4, "Dangal", LocalDate.of(2016, 12, 23), "Drama/Sports", "Hindi");

        List<Movie> movies = new ArrayList<>();
        movies.add(movie1);
        movies.add(movie2);
        movies.add(movie3);
        movies.add(movie4);
        MOVIES = List.copyOf(movies);

        LocalDate today = LocalDate.now();
        LocalDate tomorrow = today.plusDays(1);

        List<Seat> show1Seats = List.of(
                new Seat(1, SeatStatus.AVAILABLE),
                new Seat(2, SeatStatus.AVAILABLE),
                new Seat(3, SeatStatus.BLOCKED),
                new Seat(4, SeatStatus.BOOKED),
                new Seat(5, SeatStatus.AVAILABLE),
                new Seat(6, SeatStatus.AVAILABLE)
        );

        List<Seat> show2Seats = List.of(
                new Seat(1, SeatStatus.AVAILABLE),
                new Seat(2, SeatStatus.RESERVED),
                new Seat(3, SeatStatus.AVAILABLE),
                new Seat(4, SeatStatus.AVAILABLE),
                new Seat(5, SeatStatus.AVAILABLE)
        );

        List<Seat> show3Seats = List.of(
                new Seat(1, SeatStatus.AVAILABLE),
                new Seat(2, SeatStatus.AVAILABLE),
                new Seat(3, SeatStatus.AVAILABLE)
        );

        List<Seat> show4Seats = List.of(
                new Seat(1, SeatStatus.BOOKED),
                new Seat(2, SeatStatus.BOOKED),
                new Seat(3, SeatStatus.AVAILABLE),
                new Seat(4, SeatStatus.AVAILABLE)
        );

        List<Seat> show5Seats = List.of(
                new Seat(1, SeatStatus.AVAILABLE),
                new Seat(2, SeatStatus.AVAILABLE),
                new Seat(3, SeatStatus.RESERVED),
                new Seat(4, SeatStatus.AVAILABLE)
        );

        Show show1 = new Show(
                100,
                10,
                movie1.getMovieName(),
                today,
                LocalTime.of(10, 0),
                LocalTime.of(12, 30),
                show1Seats
        );

        Show show2 = new Show(
                101,
                11,
                movie2.getMovieName(),
                today,
                LocalTime.of(15, 0),
                LocalTime.of(18, 0),
                show2Seats
        );

        Show show3 = new Show(
                102,
                12,
                movie1.getMovieName(),
                today,
                LocalTime.of(18, 30),
                LocalTime.of(21, 0),
                show3Seats
        );

        Show show4 = new Show(
                103,
                20,
                movie3.getMovieName(),
                today,
                LocalTime.of(12, 0),
                LocalTime.of(15, 0),
                show4Seats
        );

        Show show5 = new Show(
                104,
                21,
                movie1.getMovieName(),
                tomorrow,
                LocalTime.of(9, 0),
                LocalTime.of(11, 30),
                show5Seats
        );

        List<Show> shows = new ArrayList<>();
        shows.add(show1);
        shows.add(show2);
        shows.add(show3);
        shows.add(show4);
        shows.add(show5);
        SHOWS = new ArrayList<>(shows);

        Screen screen1 = new Screen(10, 1, "Screen 1", "2D", new ArrayList<>(List.of(show1)));
        Screen screen2 = new Screen(11, 2, "Audi 2", "3D", new ArrayList<>(List.of(show2)));
        Screen screen3 = new Screen(12, 1, "Screen 2", "IMAX", new ArrayList<>(List.of(show3)));
        Screen screen4 = new Screen(20, 3, "Audi 1", "2D", new ArrayList<>(List.of(show4)));
        Screen screen5 = new Screen(21, 3, "Audi 2", "3D", new ArrayList<>(List.of(show5)));

        List<Screen> screens = new ArrayList<>();
        screens.add(screen1);
        screens.add(screen2);
        screens.add(screen3);
        screens.add(screen4);
        screens.add(screen5);
        SCREENS = new ArrayList<>(screens);

        Theatre theatre1 = new Theatre(1, "PVR Koramangala", "Bangalore", new ArrayList<>(List.of(screen1, screen3)));
        Theatre theatre2 = new Theatre(2, "INOX R-City", "Mumbai", new ArrayList<>(List.of(screen2)));
        Theatre theatre3 = new Theatre(3, "Cinepolis Whitefield", "Bangalore", new ArrayList<>(List.of(screen4, screen5)));

        List<Theatre> theatres = new ArrayList<>();
        theatres.add(theatre1);
        theatres.add(theatre2);
        theatres.add(theatre3);
        THEATRES = new ArrayList<>(theatres);

        Offer offer1 = new Offer(
                500,
                theatre1.getTheatreId(),
                theatre1.getCityName(),
                "50% off on the third ticket",
                today.minusDays(1),
                today.plusDays(7)
        );

        Offer offer2 = new Offer(
                501,
                theatre2.getTheatreId(),
                theatre2.getCityName(),
                "20% off on afternoon shows",
                today.minusDays(1),
                today.plusDays(30)
        );

        Offer offer3 = new Offer(
                502,
                theatre3.getTheatreId(),
                theatre3.getCityName(),
                "10% off on weekday bookings",
                today.minusDays(1),
                today.plusDays(14)
        );

        List<Offer> offers = new ArrayList<>();
        offers.add(offer1);
        offers.add(offer2);
        offers.add(offer3);
        OFFERS = List.copyOf(offers);

        List<Booking> bookings = new ArrayList<>();
        bookings.add(new Booking(9001, show1.getShowId(), BookingStatus.CONFIRMED, Instant.now(), List.of(4)));
        bookings.add(new Booking(9002, show2.getShowId(), BookingStatus.CONFIRMED, Instant.now(), List.of(2)));
        bookings.add(new Booking(9003, show4.getShowId(), BookingStatus.CONFIRMED, Instant.now(), List.of(1, 2)));
        BOOKINGS = new ArrayList<>(bookings);
    }

    private DummyDataStore() {
    }
}

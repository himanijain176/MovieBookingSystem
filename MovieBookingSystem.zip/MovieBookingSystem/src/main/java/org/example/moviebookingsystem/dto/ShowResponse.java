package org.example.moviebookingsystem.dto;

import org.example.moviebookingsystem.model.Show;
import org.example.moviebookingsystem.model.Theatre;

import java.util.List;

public record ShowResponse(
        String theatreName,
        List<Show> show){
}

package org.example.moviebookingsystem.controller;

import org.example.moviebookingsystem.dto.OfferResponse;
import org.example.moviebookingsystem.service.OfferService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Date;

@RestController
@RequestMapping("/api/v1")
public class OfferController {

    OfferService offerService;

    public OfferController(OfferService offerService){
        this.offerService = offerService;
    }

    @GetMapping("/offers")
    public ResponseEntity<OfferResponse> getOffers(
            @RequestParam Integer theatreId,
            @RequestParam String cityName,
            @RequestParam LocalDate date
            ) {
        OfferResponse offerResponse = offerService.getOffers(theatreId, cityName, date);
        return ResponseEntity.ok(offerResponse);
    }
}
